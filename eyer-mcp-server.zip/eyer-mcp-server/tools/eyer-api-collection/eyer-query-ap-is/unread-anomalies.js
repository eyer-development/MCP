/**
 * Function to retrieve unread anomalies from the Eyer API.
 *
 * @returns {Promise<Array>} - A promise that resolves to an array of unread anomalies.
 */
const executeFunction = async () => {
  const url = 'https://boomi.eyer.ai/api/v2/anomalies/unread';
  const token = "apiTokenRead";

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': token ? `Bearer ${token}` : undefined
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData);
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving unread anomalies:', error);
    return { error: 'An error occurred while retrieving unread anomalies.' };
  }
};

/**
 * Tool configuration for retrieving unread anomalies from the Eyer API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'get_unread_anomalies',
      description: 'Retrieve unread anomalies from the Eyer API.',
      parameters: {
        type: 'object',
        properties: {},
        required: []
      }
    }
  }
};

export { apiTool };