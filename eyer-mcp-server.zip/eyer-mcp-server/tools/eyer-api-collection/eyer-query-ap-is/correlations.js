/**
 * Function to retrieve correlations from the Eyer API.
 *
 * @param {Object} args - Arguments for the correlation request.
 * @returns {Promise<Array>} - The result of the correlation retrieval.
 */
const executeFunction = async () => {
  const url = 'https://topology.eyer.ai/api/correlations';
  const token = "apiTokenRead";
  
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': token ? `Bearer ${token}` : undefined
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData);
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving correlations:', error);
    return { error: 'An error occurred while retrieving correlations.' };
  }
};

/**
 * Tool configuration for retrieving correlations from the Eyer API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'get_correlations',
      description: 'Retrieve correlations from the Eyer API.',
      parameters: {
        type: 'object',
        properties: {},
        required: []
      }
    }
  }
};

export { apiTool };