/**
 * Function to retrieve nodes from the Eyer API.
 *
 * @returns {Promise<Array>} - The list of nodes from the Eyer API.
 */
const executeFunction = async () => {
  const url = 'https://topology.eyer.ai/api/definitions/nodes';
  const token = "apiTokenRead";

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': token ? `Bearer ${token}` : undefined
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData);
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving nodes:', error);
    return { error: 'An error occurred while retrieving nodes.' };
  }
};

/**
 * Tool configuration for retrieving nodes from the Eyer API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'get_nodes',
      description: 'Retrieve nodes from the Eyer API.',
      parameters: {
        type: 'object',
        properties: {},
        required: []
      }
    }
  }
};

export { apiTool };