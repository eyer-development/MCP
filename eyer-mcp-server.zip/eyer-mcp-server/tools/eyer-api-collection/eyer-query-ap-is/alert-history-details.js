/**
 * Function to retrieve alert history details from Eyer API.
 *
 * @param {Object} args - Arguments for the alert details retrieval.
 * @param {string} args.alert_id - The ID of the alert to retrieve details for.
 * @param {string} args.update_id - The ID of the update to retrieve details for.
 * @returns {Promise<Object>} - The result of the alert details retrieval.
 */
const executeFunction = async ({ alert_id, update_id }) => {
  const baseUrl = 'https://boomi.eyer.ai/api/v2/anomalies';
  const token = "apiTokenRead";
  try {
    // Construct the URL with path parameters
    const url = `${baseUrl}/${alert_id}/details/${update_id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': token ? `Bearer ${token}` : undefined
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers: Object.fromEntries(Object.entries(headers).filter(([_, v]) => v != null))
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData);
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving alert details:', error);
    return { error: 'An error occurred while retrieving alert details.' };
  }
};

/**
 * Tool configuration for retrieving alert history details from Eyer API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'get_alert_history_details',
      description: 'Retrieve alert history details from Eyer API.',
      parameters: {
        type: 'object',
        properties: {
          alert_id: {
            type: 'string',
            description: 'The ID of the alert to retrieve details for.'
          },
          update_id: {
            type: 'string',
            description: 'The ID of the update to retrieve details for.'
          }
        },
        required: ['alert_id', 'update_id']
      }
    }
  }
};

export { apiTool };