export const toolPaths = [
  'eyer-api-collection/eyer-query-ap-is/nodes.js',
  'eyer-api-collection/eyer-query-ap-is/unread-anomalies.js',
  'eyer-api-collection/eyer-query-ap-is/current-anomalies.js',
  'eyer-api-collection/eyer-query-ap-is/correlations.js',
  'eyer-api-collection/eyer-query-ap-is/alert-history.js',
  'eyer-api-collection/eyer-query-ap-is/alert-history-details.js'
];