#!/usr/bin/env node
import dotenv from "dotenv";
import express from "express";
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js';
import {
  CallToolRequestSchema,
  ErrorCode,
  ListToolsRequestSchema,
  McpError,
  ListResourcesRequestSchema,
  ListResourceTemplatesRequestSchema,
  ReadResourceRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { discoverTools } from './lib/tools.js';

dotenv.config();

const SERVER_NAME = "eyer-mcp"

async function transformTools(tools) {
  return tools.map((tool) => {
    const definitionFunction = tool.definition?.function
    if (!definitionFunction) return;
    
    // Validate and clean up the schema before returning
    const inputSchema = definitionFunction.parameters;
    if (inputSchema && inputSchema.required && inputSchema.properties) {
      // Filter required parameters to only include those that exist in properties
      const validRequired = inputSchema.required.filter(param => 
        inputSchema.properties.hasOwnProperty(param)
      );
      
      return {
        name: definitionFunction.name,
        description: definitionFunction.description,
        inputSchema: {
          ...inputSchema,
          required: validRequired
        }
      }
    }
    
    return {
      name: definitionFunction.name,
      description: definitionFunction.description,
      inputSchema: inputSchema || { type: "object", properties: {} }
    }
  }).filter(Boolean);
}

async function setupResourceHandlers(server, tools) {
  // Implement resource handlers here based on existing tools
  server.setRequestHandler(ListResourcesRequestSchema, async () => {
    // Define static resources based on tools if applicable
    const resources = tools.map(tool => {
      // Example: Create a resource for each tool's definition
      const toolName = tool.definition?.function?.name;
      if (!toolName) return null;
      return {
        uri: `tool-definition://${toolName}`,
        name: `Definition for tool: ${toolName}`,
        mimeType: 'application/json',
        description: `JSON schema definition for the ${toolName} tool`,
      };
    }).filter(Boolean);

    return { resources };
  });

  server.setRequestHandler(ListResourceTemplatesRequestSchema, async () => ({
    resourceTemplates: [
      // Define resource templates if needed, e.g., for dynamic data based on tool parameters
      // Example: A template to get the result of a tool call as a resource
      {
        uriTemplate: 'tool-result://{toolName}?args={args}',
        name: 'Result of a tool call',
        mimeType: 'application/json',
        description: 'Provides the JSON result of calling a specific tool with given arguments',
      },
    ],
  }));

  server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
    const uri = request.params.uri;

    // Handle static resources (tool definitions)
    const toolDefinitionMatch = uri.match(/^tool-definition:\/\/([^/]+)$/);
    if (toolDefinitionMatch) {
      const toolName = decodeURIComponent(toolDefinitionMatch[1]);
      const tool = tools.find((t) => t.definition?.function?.name === toolName);

      if (!tool) {
        throw new McpError(ErrorCode.NotFound, `Tool definition not found for: ${toolName}`);
      }

      return {
        contents: [{
          uri: uri,
          mimeType: 'application/json',
          text: JSON.stringify(tool.definition?.function?.parameters, null, 2),
        }],
      };
    }

    // Handle dynamic resources (tool results)
    const toolResultMatch = uri.match(/^tool-result:\/\/([^/]+)\?args=(.+)$/);
    if (toolResultMatch) {
      const toolName = decodeURIComponent(toolResultMatch[1]);
      const argsJson = decodeURIComponent(toolResultMatch[2]);
      let args;
      try {
        args = JSON.parse(argsJson);
      } catch (e) {
        throw new McpError(ErrorCode.InvalidParams, `Invalid JSON arguments: ${argsJson}`);
      }

      const tool = tools.find((t) => t.definition?.function?.name === toolName);

      if (!tool) {
        throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${toolName}`);
      }

      // Validate arguments against tool schema (optional but recommended)
      // This would require implementing schema validation logic here

      try {
        const result = await tool.function(args);
        return {
          contents: [{
            uri: uri,
            mimeType: 'application/json',
            text: JSON.stringify(result, null, 2),
          }],
        };
      } catch (error) {
        console.error('[Error] Failed to execute tool for resource:', error);
        throw new McpError(
          ErrorCode.InternalError,
          `Tool execution error: ${error.message}`
        );
      }
    }

    throw new McpError(ErrorCode.NotFound, `Unknown resource URI: ${uri}`);
  });
}

async function run() {
  const args = process.argv.slice(2);
  const isSSE = args.includes('--sse');

  const server = new Server(
    {
      name: SERVER_NAME,
      version: '0.1.0',
    },
    {
      capabilities: {
        tools: {
          tool_execution: {}
        },
        resources: {
          resource_listing: {},
          resource_templating: {},
          resource_reading: {}
        },
      },
    }
  );

  server.onerror = (error) => console.error('[Error]', error);

  // Gracefully shutdown on SIGINT
  process.on('SIGINT', async () => {
    await server.close();
    process.exit(0);
  });

  const tools = await discoverTools();

  setupResourceHandlers(server, tools);

  server.setRequestHandler(
    ListToolsRequestSchema,
    async () => ({ tools: await transformTools(tools) })
  );

  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const toolName = request.params.name;
    const tool = tools.find((t) => t.definition.function.name === toolName);

    if (!tool) {
      throw new McpError(
        ErrorCode.MethodNotFound,
        `Unknown tool: ${toolName}`
      );
    }

    const args = request.params.arguments || {};
    const toolSchema = tool.definition?.function?.parameters;
    const requiredParameters = toolSchema?.required || [];
    const availableProperties = toolSchema?.properties || {};

    // Only check for required parameters that actually exist in the schema
    for (const requiredParameter of requiredParameters) {
      if (!availableProperties.hasOwnProperty(requiredParameter)) {
        console.warn(`Warning: Required parameter '${requiredParameter}' not found in schema properties for tool '${toolName}'`);
        continue;
      }
      
      if (!(requiredParameter in args)) {
        throw new McpError(
          ErrorCode.InvalidParams,
          `Missing required parameter: ${requiredParameter}`
        );
      }
    }

    try {
      const result = await tool.function(args);
      return {
        content: [{
          type: 'text',
          text: JSON.stringify(result, null, 2),
        }],
      };
    } catch (error) {
      console.error('[Error] Failed to fetch data:', error);
      throw new McpError(
        ErrorCode.InternalError,
        `API error: ${error.message}`
      );
    }
  });

  if (isSSE) {
    const app = express();
    const transports = {};

    app.get("/messages", async (_req, res) => {
      const transport = new SSEServerTransport('/messages', res);
      transports[transport.sessionId] = transport;

      res.on("close", () => {
        delete transports[transport.sessionId];
      });

      await server.connect(transport);
    });

    app.post("/messages", async (req, res) => {
      const sessionId = req.query.sessionId;
      const transport = transports[sessionId];

      if (transport) {
        await transport.handlePostMessage(req, res);
      } else {
        res.status(400).send("No transport found for sessionId");
      }
    });

    const port = process.env.PORT || 3001;
    app.listen(port, () => {
      console.log(`[SSE Server] running on port ${port}`);
    });
  } else {
    const transport = new StdioServerTransport();
    await server.connect(transport);
  }
}

run().catch(console.error);