/**
 * Function to retrieve alert history from Eyer API.
 *
 * @param {Object} args - Arguments for the alert history retrieval.
 * @param {string} args.alert_id - The ID of the alert to retrieve history for.
 * @returns {Promise<Array>} - The alert history data.
 */
const executeFunction = async ({ alert_id }) => {
  const baseUrl = 'https://boomi.eyer.ai/api/v2/anomalies';
  const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJFeWVyIiwiaWF0Ijo0MzgsImV4cCI6NDM4LCJhdWQiOiJib29taS5leWVyLmFpICIsInN1YiI6ImV5ZXIiLCJSb2xlIjoicmVhZCIsIkNvbXBhbnkiOiJleWVyIn0.ywOjA_M7Oi_YprbEsbCz83ZXMNNyHqao8yJfaG31Ops";
  try {
    // Construct the URL for the specific alert
    const url = `${baseUrl}/${alert_id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': token ? `Bearer ${token}` : ''
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData);
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving alert history:', error);
    return { error: 'An error occurred while retrieving alert history.' };
  }
};

/**
 * Tool configuration for retrieving alert history from Eyer API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'alert_history',
      description: 'Retrieve alert history from Eyer API.',
      parameters: {
        type: 'object',
        properties: {
          alert_id: {
            type: 'string',
            description: 'The ID of the alert to retrieve history for.'
          }
        },
        required: ['alert_id']
      }
    }
  }
};

export { apiTool };