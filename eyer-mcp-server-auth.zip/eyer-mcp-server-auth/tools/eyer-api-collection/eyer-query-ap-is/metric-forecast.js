/**
 * Function to retrieve metric forecast from Eyer API.
 *
 * @param {Object} args - Arguments for the metric forecast retrieval.
 * @param {string} args.node_id - The ID of the node to retrieve forecast for.
 * @param {string} args.metric_id - The ID of the metric to retrieve forecast for.
 * @returns {Promise<Array>} - The metric forecast data.
 */
const executeFunction = async ({ node_id, metric_id }) => {
  const baseUrl = 'https://api.eyer.ai/v1/ad/corridors';
  const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJFeWVyIiwiaWF0Ijo0MzgsImV4cCI6NDM4LCJhdWQiOiJib29taS5leWVyLmFpICIsInN1YiI6ImV5ZXIiLCJSb2xlIjoicmVhZCIsIkNvbXBhbnkiOiJleWVyIn0.ywOjA_M7Oi_YprbEsbCz83ZXMNNyHqao8yJfaG31Ops";
  try {
    // Construct the URL for the specific alert
    const url = `${baseUrl}/${node_id}/${metric_id}/forecast`;
    // Set up headers for the request
    const headers = {
      'Authorization': token ? `Bearer ${token}` : ''
    };
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });
    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData);
    }
    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving metric forecast:', error);
    return { error: 'An error occurred while retrieving metric forecast.' };
  }
};

/**
 * Tool configuration for retrieving metric forecast from Eyer API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'metric_forecast',
      description: 'Retrieve metric forecast from Eyer API.',
      parameters: {
        type: 'object',
        properties: {
          node_id: {
            type: 'string',
            description: 'The ID of the node to retrieve forecast for.'
          },
          metric_id: {
            type: 'string',
            description: 'The ID of the metric to retrieve forecast for.'
          }
        },
        required: ['node_id', 'metric_id']
      }
    }
  }
};

export { apiTool };