#!/usr/bin/env node
import dotenv from "dotenv";
import express from "express";
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js';
import {
  CallToolRequestSchema,
  ErrorCode,
  ListToolsRequestSchema,
  McpError,
  ListResourcesRequestSchema,
  ListResourceTemplatesRequestSchema,
  ReadResourceRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { discoverTools } from './lib/tools.js';

dotenv.config();

const SERVER_NAME = "eyer-mcp"

async function transformTools(tools) {
  return tools.map((tool) => {
    const definitionFunction = tool.definition?.function
    if (!definitionFunction) return;
    
    // Clean up the schema to be Gemini-compatible
    const inputSchema = definitionFunction.parameters || {};
    
    // Ensure we have proper schema structure
    const cleanSchema = {
      type: inputSchema.type || "object",
      properties: inputSchema.properties || {},
      required: []
    };
    
    // Auto-fix common missing properties for known tools
    if (definitionFunction.name === "metric_forecast" && inputSchema.required?.includes("node_id") && !cleanSchema.properties.node_id) {
      cleanSchema.properties.node_id = {
        type: "string",
        description: "The ID of the node to retrieve forecast for"
      };
    }
    
    // Only include required parameters that actually exist in properties
    if (inputSchema.required && Array.isArray(inputSchema.required)) {
      cleanSchema.required = inputSchema.required.filter(param => 
        cleanSchema.properties && cleanSchema.properties.hasOwnProperty(param)
      );
    }
    
    // Remove empty required array if no valid required parameters
    if (cleanSchema.required.length === 0) {
      delete cleanSchema.required;
    }
    
    return {
      name: definitionFunction.name,
      description: definitionFunction.description || `Execute ${definitionFunction.name}`,
      inputSchema: cleanSchema
    }
  }).filter(Boolean);
}

async function setupResourceHandlers(server, tools) {
  // Implement resource handlers here based on existing tools
  server.setRequestHandler(ListResourcesRequestSchema, async () => {
    // Define static resources based on tools if applicable
    const resources = tools.map(tool => {
      // Example: Create a resource for each tool's definition
      const toolName = tool.definition?.function?.name;
      if (!toolName) return null;
      return {
        uri: `tool-definition://${toolName}`,
        name: `Definition for tool: ${toolName}`,
        mimeType: 'application/json',
        description: `JSON schema definition for the ${toolName} tool`,
      };
    }).filter(Boolean);

    return { resources };
  });

  server.setRequestHandler(ListResourceTemplatesRequestSchema, async () => ({
    resourceTemplates: [
      // Define resource templates if needed, e.g., for dynamic data based on tool parameters
      // Example: A template to get the result of a tool call as a resource
      {
        uriTemplate: 'tool-result://{toolName}?args={args}',
        name: 'Result of a tool call',
        mimeType: 'application/json',
        description: 'Provides the JSON result of calling a specific tool with given arguments',
      },
    ],
  }));

  server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
    const uri = request.params.uri;

    // Handle static resources (tool definitions)
    const toolDefinitionMatch = uri.match(/^tool-definition:\/\/([^/]+)$/);
    if (toolDefinitionMatch) {
      const toolName = decodeURIComponent(toolDefinitionMatch[1]);
      const tool = tools.find((t) => t.definition?.function?.name === toolName);

      if (!tool) {
        throw new McpError(ErrorCode.NotFound, `Tool definition not found for: ${toolName}`);
      }

      return {
        contents: [{
          uri: uri,
          mimeType: 'application/json',
          text: JSON.stringify(tool.definition?.function?.parameters, null, 2),
        }],
      };
    }

    // Handle dynamic resources (tool results)
    const toolResultMatch = uri.match(/^tool-result:\/\/([^/]+)\?args=(.+)$/);
    if (toolResultMatch) {
      const toolName = decodeURIComponent(toolResultMatch[1]);
      const argsJson = decodeURIComponent(toolResultMatch[2]);
      let args;
      try {
        args = JSON.parse(argsJson);
      } catch (e) {
        throw new McpError(ErrorCode.InvalidParams, `Invalid JSON arguments: ${argsJson}`);
      }

      const tool = tools.find((t) => t.definition?.function?.name === toolName);

      if (!tool) {
        throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${toolName}`);
      }

      try {
        const result = await tool.function(args);
        return {
          contents: [{
            uri: uri,
            mimeType: 'application/json',
            text: JSON.stringify(result, null, 2),
          }],
        };
      } catch (error) {
        console.error('[Error] Failed to execute tool for resource:', error);
        throw new McpError(
          ErrorCode.InternalError,
          `Tool execution error: ${error.message}`
        );
      }
    }

    throw new McpError(ErrorCode.NotFound, `Unknown resource URI: ${uri}`);
  });
}

async function run() {
  const args = process.argv.slice(2);
  const isSSE = args.includes('--sse');

  const server = new Server(
    {
      name: SERVER_NAME,
      version: '0.1.0',
    },
    {
      capabilities: {
        tools: {
          tool_execution: {}
        },
        resources: {
          resource_listing: {},
          resource_templating: {},
          resource_reading: {}
        },
      },
    }
  );

  server.onerror = (error) => console.error('[Error]', error);

  // Gracefully shutdown on SIGINT
  process.on('SIGINT', async () => {
    await server.close();
    process.exit(0);
  });

  const tools = await discoverTools();

  // Debug: Log tool schemas to identify issues
  tools.forEach((tool, index) => {
    const schema = tool.definition?.function?.parameters;
    if (schema?.required && schema?.properties) {
      const missingProps = schema.required.filter(req => !schema.properties.hasOwnProperty(req));
      if (missingProps.length > 0) {
        console.warn(`Warning: Tool ${index} (${tool.definition.function.name}) has required parameters not in properties:`, missingProps);
      }
    }
  });

  setupResourceHandlers(server, tools);

  server.setRequestHandler(
    ListToolsRequestSchema,
    async () => ({ tools: await transformTools(tools) })
  );

  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const toolName = request.params.name;
    const tool = tools.find((t) => t.definition?.function?.name === toolName);

    if (!tool) {
      throw new McpError(
        ErrorCode.MethodNotFound,
        `Unknown tool: ${toolName}`
      );
    }

    const args = request.params.arguments || {};
    const toolSchema = tool.definition?.function?.parameters;
    const requiredParameters = toolSchema?.required || [];
    const availableProperties = toolSchema?.properties || {};

    // Validate required parameters, but only check those that exist in schema
    for (const requiredParameter of requiredParameters) {
      // Skip validation if the parameter isn't properly defined in the schema
      if (!availableProperties.hasOwnProperty(requiredParameter)) {
        console.warn(`Skipping validation for undefined required parameter: ${requiredParameter} in tool: ${toolName}`);
        continue;
      }
      
      if (!(requiredParameter in args)) {
        throw new McpError(
          ErrorCode.InvalidParams,
          `Missing required parameter: ${requiredParameter}`
        );
      }
    }

    try {
      const result = await tool.function(args);
      return {
        content: [{
          type: 'text',
          text: JSON.stringify(result, null, 2),
        }],
      };
    } catch (error) {
      console.error('[Error] Failed to fetch data:', error);
      throw new McpError(
        ErrorCode.InternalError,
        `API error: ${error.message}`
      );
    }
  });

  if (isSSE) {
    const app = express();
    const transports = {};

    // Enhanced middleware for token authorization with better error handling
    const authenticateToken = (req, res, next) => {
      const authHeader = req.headers['authorization'];
      const token = authHeader && authHeader.split(' ')[1]; // Extract token from "Bearer TOKEN"

      // Use environment variable for token validation
      const VALID_TOKEN = process.env.AUTH_TOKEN || 'your_secret_token';

      if (token == null) {
        return res.status(401).json({ error: 'No authorization token provided' });
      }
      
      if (token !== VALID_TOKEN) {
        return res.status(401).json({ error: 'Invalid authorization token' });
      }

      next(); // Proceed to the next middleware/route handler
    };

    // Add CORS headers for cross-origin requests
    app.use((req, res, next) => {
      res.header('Access-Control-Allow-Origin', '*');
      res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
      
      if (req.method === 'OPTIONS') {
        res.sendStatus(200);
      } else {
        next();
      }
    });

    // DO NOT add express.json() middleware here - it interferes with SSE transport
    // The SSE transport needs to handle the raw request body itself

    app.get("/messages", authenticateToken, async (req, res) => {
      try {
        const transport = new SSEServerTransport('/messages', res);
        transports[transport.sessionId] = transport;

        res.on("close", () => {
          delete transports[transport.sessionId];
        });

        await server.connect(transport);
      } catch (error) {
        console.error('[Error] Failed to establish SSE connection:', error);
        res.status(500).json({ error: 'Failed to establish connection' });
      }
    });

    app.post("/messages", authenticateToken, async (req, res) => {
      try {
        const sessionId = req.query.sessionId;
        const transport = transports[sessionId];

        if (transport) {
          await transport.handlePostMessage(req, res);
        } else {
          res.status(400).json({ error: "No transport found for sessionId" });
        }
      } catch (error) {
        console.error('[Error] Failed to handle POST message:', error);
        res.status(500).json({ error: 'Failed to handle message' });
      }
    });

    // Health check endpoint
    app.get("/health", (req, res) => {
      res.json({ status: "healthy", server: SERVER_NAME, version: "0.1.0" });
    });

    const port = process.env.PORT || 3001;
    app.listen(port, () => {
      console.log(`[SSE Server] ${SERVER_NAME} running on port ${port}`);
      console.log(`Health check available at: http://localhost:${port}/health`);
    });
  } else {
    const transport = new StdioServerTransport();
    await server.connect(transport);
  }
}

run().catch(console.error);